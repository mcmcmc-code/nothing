import { _decorator, Component, Node, Sprite, SpriteFrame, RigidBody2D, Vec2, v2, tween, v3, ParticleSystem2D, Graphics, UITransform, Mask, Tween, easing, Color } from 'cc';
const { ccclass, property } = _decorator;

/**
 * Controls the physical destruction animations of a task note.
 * Attach this to the "StickyNote" prefab root.
 */
@ccclass('DestructionController')
export class DestructionController extends Component {
    // FIX: Explicitly declare properties that might be missing from the environment's Component type definition
    public declare node: Node;
    public declare scheduleOnce: (callback: (dt?: number) => void, delay?: number) => void;

    @property({ type: SpriteFrame, tooltip: 'The crumpled paper sprite frame (Frame 1)' })
    public spriteWrinkled: SpriteFrame | null = null;

    @property({ type: SpriteFrame, tooltip: 'The paper ball sprite frame (Frame 2)' })
    public spriteBall: SpriteFrame | null = null;

    @property({ type: ParticleSystem2D, tooltip: 'Confetti particles for the shredder effect' })
    public confettiParticle: ParticleSystem2D | null = null;

    private sprite: Sprite | null = null;
    private rigidBody: RigidBody2D | null = null;
    private initialPos: Vec2 = v2(0, 0);

    start() {
        this.sprite = this.node.getComponent(Sprite) || this.node.getComponentInChildren(Sprite);
        this.rigidBody = this.node.getComponent(RigidBody2D);
        this.initialPos = v2(this.node.position.x, this.node.position.y);

        // Ensure particles are off initially
        if (this.confettiParticle) {
            this.confettiParticle.stopSystem();
        }
    }

    /**
     * Public API to trigger destruction modes.
     */
    public triggerDestruction(mode: 'SHREDDER' | 'CRUMPLE' | 'BALLOON') {
        switch (mode) {
            case 'SHREDDER':
                this.playShredder();
                break;
            case 'CRUMPLE':
                this.playCrumple();
                break;
            case 'BALLOON':
                this.playBalloon();
                break;
        }
    }

    // ========================================================================
    // Mode 1: SHREDDER (Anxiety Relief)
    // ========================================================================
    private playShredder() {
        // 1. Setup Masking
        // Create a mask node (the "shredder mouth")
        const maskNode = new Node('ShredderMask');
        maskNode.layer = this.node.layer;
        
        // Position mask at current node location
        maskNode.setPosition(this.node.position);
        maskNode.parent = this.node.parent;

        // Add Mask Component (Rect, Inverted = true)
        const mask = maskNode.addComponent(Mask);
        mask.type = Mask.Type.RECT;
        mask.inverted = false; // We want to see inside the rect, but we'll move the node OUT of it
        
        // Set mask size (same as node size)
        const uiTransform = this.node.getComponent(UITransform);
        const width = uiTransform ? uiTransform.width : 200;
        const height = uiTransform ? uiTransform.height : 200;
        maskNode.getComponent(UITransform).setContentSize(width, height * 2); // Tall mask

        // 2. Reparent Node
        // We need the node to move *relative* to the mask.
        // Since Cocos coordinate systems can be tricky with reparenting, 
        // we essentially zero out the node's position inside the mask.
        const worldPos = this.node.getWorldPosition();
        this.node.parent = maskNode;
        this.node.setWorldPosition(worldPos);

        // 3. Animation: Move Down
        tween(this.node)
            .by(2.0, { position: v3(0, -height - 50, 0) }, { easing: 'linear' })
            .call(() => {
                this.node.destroy();
                maskNode.destroy();
            })
            .start();

        // 4. FX: Particles
        if (this.confettiParticle) {
            // Reparent particles to world so they don't get masked
            const pWorldPos = this.confettiParticle.node.getWorldPosition();
            this.confettiParticle.node.parent = maskNode.parent; // Scene/Canvas
            this.confettiParticle.node.setWorldPosition(pWorldPos);
            this.confettiParticle.node.active = true;
            this.confettiParticle.resetSystem();
        }

        // 5. Haptic
        // TODO: Call Native HarmonyOS Vibrator here (Continuous Hum)
        console.log('[Haptics] Continuous Hum triggered');
    }

    // ========================================================================
    // Mode 2: CRUMPLE (Anger Release)
    // ========================================================================
    private playCrumple() {
        if (!this.sprite) return;

        // 1. Sprite Animation Sequence
        const duration = 0.05;
        
        // Frame 1: Wrinkled
        this.scheduleOnce(() => {
            if (this.spriteWrinkled) this.sprite!.spriteFrame = this.spriteWrinkled;
        }, duration);

        // Frame 2: Ball + Physics Launch
        this.scheduleOnce(() => {
            if (this.spriteBall) this.sprite!.spriteFrame = this.spriteBall;
            this.launchBall();
        }, duration * 2);
    }

    private launchBall() {
        if (!this.rigidBody) return;

        // Enable physics
        this.rigidBody.type = RigidBody2D.Type.Dynamic;
        this.rigidBody.enabledContactListener = true;

        // Apply Forces
        // Throw upward and slightly sideways
        const xForce = (Math.random() - 0.5) * 50; 
        const yForce = 100; // Strong upward force
        const impulse = v2(xForce, yForce);
        
        this.rigidBody.applyLinearImpulseToCenter(impulse, true);

        // Apply Spin
        const torque = (Math.random() > 0.5 ? 1 : -1) * 5000;
        this.rigidBody.applyTorque(torque, true);

        // Fade out after a while
        tween(this.node.getComponent(UITransform))
            .delay(2.0)
            .to(1.0, { opacity: 0 } as any) // Type casting for opacity tween
            .call(() => this.node.destroy())
            .start();

        // Haptics
        // TODO: Call Native HarmonyOS Vibrator here (Heavy Impact)
        console.log('[Haptics] Heavy Impact triggered');
    }

    // ========================================================================
    // Mode 3: BALLOON (Freedom)
    // ========================================================================
    private playBalloon() {
        // 1. Draw "String" (Visual only, simple line to top of screen)
        const g = this.node.addComponent(Graphics);
        g.lineWidth = 2;
        g.strokeColor = new Color(200, 200, 200, 255); // String color
        g.moveTo(0, 50); // Top of note
        g.lineTo(0, 500); // Way up
        g.stroke();

        // 2. "Cut" the string sequence
        this.scheduleOnce(() => {
            g.clear(); // String gone
            
            // 3. Physics: Float Up
            if (this.rigidBody) {
                this.rigidBody.type = RigidBody2D.Type.Dynamic;
                this.rigidBody.gravityScale = -0.2; // Negative gravity to float
                this.rigidBody.linearDamping = 0.5;
            }

            // 4. Animation: Drift and Fade
            // Sine wave drift on X axis while physics handles Y
            const startX = this.node.position.x;
            const driftTween = tween(this.node)
                .by(3.0, { position: v3(50, 0, 0) }, { easing: 'sineInOut' })
                .start();

            // Fade out
            tween(this.node.getComponent(UITransform))
                .to(3.0, { opacity: 0 } as any)
                .call(() => this.node.destroy())
                .start();

        }, 0.5); // Delay before cutting

        // Haptics
        // TODO: Call Native HarmonyOS Vibrator here (Light Tickle)
        console.log('[Haptics] Light Tickle triggered');
    }
}