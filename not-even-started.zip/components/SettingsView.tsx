import React from 'react';
import { motion } from 'framer-motion';
import { RefreshCw, Github, Heart } from 'lucide-react';

interface SettingsViewProps {
  onReset: () => void;
}

const SettingsView: React.FC<SettingsViewProps> = ({ onReset }) => {
  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="px-6 py-4 space-y-4"
    >
      <div className="bg-white/60 backdrop-blur-md rounded-2xl overflow-hidden border border-white/50 shadow-soft">
        <div className="p-6 border-b border-ink/5">
          <h3 className="font-serif text-xl text-ink">Preferences</h3>
        </div>
        
        <button 
          onClick={onReset}
          className="w-full flex items-center gap-4 p-6 hover:bg-paper-yellow/50 transition-colors text-left group"
        >
          <div className="w-10 h-10 rounded-full bg-ink/5 flex items-center justify-center text-ink group-hover:bg-accent-orange group-hover:text-white transition-colors">
            <RefreshCw size={18} />
          </div>
          <div>
            <p className="font-sans font-medium text-ink">Reset Progress</p>
            <p className="text-sm text-ink-light">Clear all history and energy saved</p>
          </div>
        </button>
      </div>

      <div className="bg-white/60 backdrop-blur-md rounded-2xl overflow-hidden border border-white/50 shadow-soft p-6">
        <div className="flex items-center gap-4 mb-6">
          <div className="w-10 h-10 rounded-full bg-red-50 flex items-center justify-center text-red-400">
            <Heart size={18} fill="currentColor" />
          </div>
          <div>
            <p className="font-sans font-medium text-ink">About</p>
            <p className="text-sm text-ink-light">Designed for peace of mind</p>
          </div>
        </div>
        <p className="font-serif italic text-ink/60 text-sm leading-relaxed">
          Not Even Started is a conceptual "Anti-To-Do" list. It helps you prioritize by explicitly deciding what NOT to do.
        </p>
      </div>
    </motion.div>
  );
};

export default SettingsView;