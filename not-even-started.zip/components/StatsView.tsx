import React from 'react';
import { motion } from 'framer-motion';
import { Wind, Trash2, Zap, History } from 'lucide-react';
import { Task } from '../types';

interface StatsViewProps {
  energySaved: number;
  tasksGivenUp: number;
  history: Task[];
}

const StatsView: React.FC<StatsViewProps> = ({ energySaved, tasksGivenUp, history }) => {
  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="px-6 py-8 space-y-6"
    >
      <div className="bg-white/50 backdrop-blur-sm p-8 rounded-2xl border border-white/60 shadow-soft">
        <div className="flex items-start justify-between mb-4">
          <div className="p-3 bg-accent-orange/10 rounded-xl text-accent-orange">
            <Zap size={24} />
          </div>
        </div>
        <h3 className="text-ink-light text-sm font-sans font-medium uppercase tracking-wider mb-1">
          Total Energy Saved
        </h3>
        <p className="font-serif text-6xl text-ink font-medium">
          {energySaved} <span className="text-2xl text-ink/40 font-normal italic">kcal</span>
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-paper-grey/50 p-6 rounded-2xl border border-white/60 shadow-soft">
           <Trash2 size={20} className="text-ink-light mb-3" />
           <p className="text-3xl font-serif text-ink mb-1">{tasksGivenUp}</p>
           <p className="text-xs text-ink-light uppercase tracking-wide font-bold">Burdens Released</p>
        </div>
        <div className="bg-paper-latte/50 p-6 rounded-2xl border border-white/60 shadow-soft">
           <Wind size={20} className="text-ink-light mb-3" />
           <p className="text-3xl font-serif text-ink mb-1">{(energySaved / 150).toFixed(1)}</p>
           <p className="text-xs text-ink-light uppercase tracking-wide font-bold">Hours Gained</p>
        </div>
      </div>
      
      {/* History Section */}
      <div className="mt-6">
        <div className="flex items-center gap-2 mb-4 px-1">
          <History size={16} className="text-ink-light" />
          <h3 className="text-ink-light text-sm font-sans font-bold uppercase tracking-wider">
            History of Letting Go
          </h3>
        </div>
        
        <div className="space-y-3">
          {history.length === 0 ? (
            <p className="text-ink-light/50 text-sm italic px-1">No burdens released yet.</p>
          ) : (
            history.map((task) => (
              <div 
                key={task.id}
                className="bg-white/40 border border-white/60 rounded-xl p-4 flex items-center justify-between shadow-sm"
              >
                <div>
                  <div className="flex items-center gap-2">
                    {task.sticker && <span className="text-lg">{task.sticker}</span>}
                    <p className="font-hand text-xl text-ink line-through decoration-accent-orange/50 decoration-2">
                      {task.text}
                    </p>
                  </div>
                  <p className="text-[10px] text-ink-light font-sans mt-1">
                    Released on {task.date}
                  </p>
                </div>
                <span className="text-xs font-bold text-accent-orange bg-accent-orange/10 px-2 py-1 rounded-full">
                  +{task.energy} kcal
                </span>
              </div>
            ))
          )}
        </div>
      </div>
      
      <div className="mt-8 p-6 text-center">
         <p className="font-hand text-2xl text-ink/60 leading-relaxed">
           "The art of being wise is the art of knowing what to overlook."
         </p>
         <p className="font-sans text-xs font-bold text-ink-light/40 mt-3 uppercase tracking-widest">
           William James
         </p>
      </div>
    </motion.div>
  );
};

export default StatsView;