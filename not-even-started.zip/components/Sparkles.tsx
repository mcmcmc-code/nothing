import React from 'react';
import { motion } from 'framer-motion';
import { SparkleType } from '../types';

interface SparklesProps {
  sparkles: SparkleType[];
}

const Sparkles: React.FC<SparklesProps> = ({ sparkles }) => {
  return (
    <div className="pointer-events-none fixed inset-0 z-50 overflow-hidden">
      {sparkles.map((sparkle) => (
        <motion.div
          key={sparkle.id}
          initial={{ 
            x: sparkle.x, 
            y: sparkle.y, 
            scale: 0, 
            opacity: 1 
          }}
          animate={{ 
            x: sparkle.x + (Math.random() - 0.5) * 150, 
            y: sparkle.y + (Math.random() - 0.5) * 150, 
            scale: [0, 1, 0], 
            opacity: [1, 1, 0],
            rotate: Math.random() * 360
          }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="absolute w-3 h-3 rounded-full"
          style={{ backgroundColor: sparkle.color }}
        />
      ))}
    </div>
  );
};

export default Sparkles;