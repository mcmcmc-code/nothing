import React, { useMemo } from 'react';
import { motion, useMotionValue, useTransform } from 'framer-motion';
import { Task } from '../types';
import { X } from 'lucide-react';

interface StickyNoteProps {
  task: Task;
  onGiveUp: (id: string, x: number, y: number) => void;
  index: number;
}

const colorMap = {
  yellow: 'bg-paper-yellow',
  grey: 'bg-paper-grey',
  latte: 'bg-paper-latte',
  white: 'bg-paper-white'
};

const StickyNote: React.FC<StickyNoteProps> = ({ task, onGiveUp, index }) => {
  const x = useMotionValue(0);
  const rotate = useTransform(x, [-100, 100], [-10, 10]);
  
  // Random slight delay for entrance to feel organic
  const delay = index * 0.1;

  // Randomize the exit animation type on mount
  const exitAnimation = useMemo(() => {
    const seed = Math.random();
    
    // 1. Crumple & Drop (Gravity) - 20%
    if (seed < 0.2) {
      return {
        scale: 0.4,
        rotate: task.rotation + 45 + Math.random() * 90,
        y: 150,
        opacity: 0,
        filter: "blur(2px) grayscale(100%)",
        transition: { duration: 0.5, ease: "backIn" }
      };
    }
    
    // 2. Float Away (Ascension) - 20%
    if (seed < 0.4) {
      return {
        y: -200,
        x: (Math.random() - 0.5) * 60,
        rotate: (Math.random() - 0.5) * 20,
        scale: 0.9,
        opacity: 0,
        transition: { duration: 0.8, ease: "circOut" }
      };
    }
    
    // 3. Dissolve (Burn/Magic) - 20%
    if (seed < 0.6) {
      return {
        scale: 1.1,
        opacity: 0,
        filter: "brightness(1.5) blur(8px)",
        transition: { duration: 0.4, ease: "easeOut" }
      };
    }

    // 4. Rip/Tear (Shear) - 20%
    // Simulates the paper being pulled/sheared apart aggressively
    if (seed < 0.8) {
      return {
        skewX: -25,
        x: -30,
        scaleY: 0.9,
        opacity: 0,
        transition: { duration: 0.3, ease: "anticipate" }
      };
    }

    // 5. Explode (Pop) - 20%
    // Rapid expansion and brightness bloom
    return {
      scale: 1.6,
      opacity: 0,
      filter: "brightness(2) contrast(1.2)",
      transition: { duration: 0.25, ease: "easeOut" }
    };

  }, [task.rotation]);

  const handleClick = (e: React.MouseEvent) => {
    // Get click coordinates for sparkle origin
    const rect = (e.target as HTMLElement).getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    onGiveUp(task.id, centerX, centerY);
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 50, rotate: task.rotation }}
      animate={{ opacity: 1, y: 0, rotate: task.rotation }}
      exit={exitAnimation}
      transition={{ 
        type: "spring", 
        stiffness: 260, 
        damping: 20, 
        delay: delay 
      }}
      whileHover={{ 
        scale: 1.02, 
        rotate: 0, 
        zIndex: 10, 
        boxShadow: "0 25px 30px -10px rgba(0, 0, 0, 0.15)"
      }}
      whileTap={{ scale: 0.95 }}
      onClick={handleClick}
      className={`
        relative 
        ${colorMap[task.color]} 
        p-4 md:p-6 
        rounded-sm 
        shadow-paper 
        cursor-pointer 
        break-inside-avoid 
        mb-4
        transform-gpu
        group
        overflow-hidden
      `}
      style={{
        rotate: task.rotation,
      }}
    >
      {/* Paper texture overlay for this specific note */}
      <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/cream-paper.png')] mix-blend-multiply pointer-events-none rounded-sm" />
      
      {/* Sticker */}
      {task.sticker && (
        <div className="absolute top-2 right-2 text-xl md:text-2xl opacity-80 mix-blend-multiply rotate-12 filter drop-shadow-sm">
          {task.sticker}
        </div>
      )}
      
      <div className="relative z-10 flex flex-col gap-3">
        <div className="flex justify-between items-start opacity-40 group-hover:opacity-100 transition-opacity duration-300">
           <span className="text-[10px] uppercase tracking-widest font-sans font-bold text-ink-light">
             Give Up
           </span>
           <X size={14} className="text-ink-light" />
        </div>
        
        <p className="font-hand text-2xl md:text-3xl text-ink leading-[1.1] pr-2 break-words">
          {task.text}
        </p>
        
        <div className="mt-2 flex items-center justify-between border-t border-ink/5 pt-3">
          <span className="font-sans text-[10px] text-ink-light/60 font-medium tracking-wide">
             EST. {task.energy} KCAL
          </span>
          <span className="font-sans text-[10px] text-ink-light/60">
             {task.date}
          </span>
        </div>
      </div>
    </motion.div>
  );
};

export default StickyNote;