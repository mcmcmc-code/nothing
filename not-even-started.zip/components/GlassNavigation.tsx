import React from 'react';
import { Feather, Home, Settings, BarChart2 } from 'lucide-react';
import { Tab } from '../types';

interface GlassNavigationProps {
  onAddClick: () => void;
  activeTab: Tab;
  onTabChange: (tab: Tab) => void;
}

const GlassNavigation: React.FC<GlassNavigationProps> = ({ onAddClick, activeTab, onTabChange }) => {
  const getIconClass = (tab: Tab) => `
    p-3 rounded-xl transition-all duration-300 relative
    ${activeTab === tab ? 'text-accent-orange bg-accent-orange/10' : 'text-ink-light hover:text-ink hover:bg-ink/5'}
  `;

  return (
    <>
      <div className="fixed bottom-0 left-0 right-0 z-40 px-6 pb-[calc(1.5rem+env(safe-area-inset-bottom))] pt-0 flex justify-center pointer-events-none">
        {/* Navigation Bar */}
        <div className="pointer-events-auto relative flex items-center justify-between gap-6 px-6 py-3 bg-white/80 backdrop-blur-xl border border-white/40 shadow-float rounded-2xl min-w-[280px]">
           <button 
             onClick={() => onTabChange('home')}
             className={getIconClass('home')}
             aria-label="Home"
           >
              <Home size={24} strokeWidth={activeTab === 'home' ? 2 : 1.5} />
           </button>
           
           <button 
             onClick={() => onTabChange('stats')}
             className={getIconClass('stats')}
             aria-label="Statistics"
           >
              <BarChart2 size={24} strokeWidth={activeTab === 'stats' ? 2 : 1.5} />
           </button>

           {/* Spacer for FAB */}
           <div className="w-12" />
           
           <button 
             onClick={() => onTabChange('settings')}
             className={getIconClass('settings')}
             aria-label="Settings"
           >
              <Settings size={24} strokeWidth={activeTab === 'settings' ? 2 : 1.5} />
           </button>
        </div>
      </div>

      {/* Floating Action Button */}
      <button 
        onClick={onAddClick}
        className="
          fixed bottom-[calc(2.5rem+env(safe-area-inset-bottom))] left-1/2 -translate-x-1/2 z-50 
          w-16 h-16 
          bg-gradient-to-br from-[#FFFEF0] to-[#EBE4D6] 
          border border-white 
          rounded-full 
          shadow-[0_10px_20px_rgba(217,119,6,0.25)] 
          flex items-center justify-center
          text-accent-orange
          hover:scale-110 active:scale-95 transition-transform duration-300
          group
        "
        aria-label="Add Task"
      >
        <Feather size={28} className="group-hover:rotate-12 transition-transform duration-300" />
      </button>
    </>
  );
};

export default GlassNavigation;