import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Check } from 'lucide-react';
import { Task } from '../types';

interface AddTaskModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (text: string, color: Task['color'], sticker: string) => void;
}

const colorMap = {
  yellow: 'bg-paper-yellow',
  grey: 'bg-paper-grey',
  latte: 'bg-paper-latte',
  white: 'bg-paper-white'
};

const stickers = ['🌿', '☕', '🧘', '🥀', '🕊️', '☁️', '🌙'];

const AddTaskModal: React.FC<AddTaskModalProps> = ({ isOpen, onClose, onAdd }) => {
  const [text, setText] = useState('');
  const [selectedColor, setSelectedColor] = useState<Task['color']>('yellow');
  const [selectedSticker, setSelectedSticker] = useState<string>('');

  useEffect(() => {
    if (isOpen) {
      setText('');
      setSelectedColor('yellow');
      setSelectedSticker('');
    }
  }, [isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (text.trim()) {
      onAdd(text, selectedColor, selectedSticker);
      onClose();
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-ink/20 backdrop-blur-sm z-50 flex items-center justify-center p-4 pt-[env(safe-area-inset-top)] pb-[env(safe-area-inset-bottom)]"
          >
          </motion.div>
          
          {/* Modal Card */}
          <motion.div
             className="fixed inset-0 z-50 flex items-center justify-center pointer-events-none p-4"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className={`
                pointer-events-auto
                w-full max-w-sm 
                ${colorMap[selectedColor]} 
                shadow-2xl 
                rounded-sm 
                p-6 md:p-8 
                relative
                flex flex-col
                max-h-[85dvh]
              `}
            >
              <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/cream-paper.png')] mix-blend-multiply pointer-events-none rounded-sm" />

              <button 
                onClick={onClose}
                className="absolute top-4 right-4 text-ink/40 hover:text-ink transition-colors p-2"
              >
                <X size={24} />
              </button>

              <h2 className="font-sans text-xs font-bold uppercase tracking-widest text-ink-light mb-4 mt-2">
                What do you want to give up?
              </h2>

              <textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Writing a novel..."
                className="
                  flex-1 
                  bg-transparent 
                  border-none 
                  resize-none 
                  outline-none 
                  font-hand 
                  text-3xl md:text-4xl 
                  text-ink 
                  placeholder:text-ink/20
                  leading-tight
                  min-h-[100px]
                "
                autoFocus
              />

              {/* Sticker Selector */}
              <div className="mb-6 mt-4">
                <p className="font-sans text-[10px] font-bold uppercase tracking-widest text-ink-light/60 mb-2">
                  Add a sticker
                </p>
                <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide -mx-2 px-2">
                  {stickers.map((s) => (
                    <button
                      key={s}
                      onClick={() => setSelectedSticker(s === selectedSticker ? '' : s)}
                      className={`
                        w-10 h-10 flex-shrink-0 flex items-center justify-center text-2xl rounded-full
                        transition-all duration-200
                        ${selectedSticker === s ? 'bg-ink/10 scale-110' : 'hover:bg-ink/5'}
                      `}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between">
                {/* Color Picker */}
                <div className="flex gap-3">
                  {(['yellow', 'grey', 'latte', 'white'] as Task['color'][]).map((c) => (
                    <button
                      key={c}
                      onClick={() => setSelectedColor(c)}
                      className={`
                        w-8 h-8 rounded-full border border-ink/10 shadow-sm
                        ${colorMap[c]} 
                        ${selectedColor === c ? 'ring-2 ring-ink ring-offset-1' : ''}
                      `}
                    />
                  ))}
                </div>

                {/* Submit Button */}
                <button
                  onClick={handleSubmit}
                  disabled={!text.trim()}
                  className="
                    flex items-center gap-2 
                    bg-ink text-white 
                    px-5 py-3 
                    rounded-full 
                    font-sans text-sm font-medium
                    disabled:opacity-50 disabled:cursor-not-allowed
                    hover:bg-accent-orange transition-colors
                    shadow-lg
                  "
                >
                  <span>Let go</span>
                  <Check size={16} />
                </button>
              </div>
            </motion.div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default AddTaskModal;