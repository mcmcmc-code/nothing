export interface Task {
  id: string;
  text: string;
  color: 'yellow' | 'grey' | 'latte' | 'white';
  rotation: number;
  energy: number; // Simulated kcal saved by giving up
  date: string;
  sticker?: string;
}

export interface SparkleType {
  id: string;
  x: number;
  y: number;
  color: string;
}

export type Tab = 'home' | 'stats' | 'settings';