import React, { useState, useCallback, useRef } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Coffee, Wind } from 'lucide-react';
import StickyNote from './components/StickyNote';
import NoiseOverlay from './components/NoiseOverlay';
import GlassNavigation from './components/GlassNavigation';
import Sparkles from './components/Sparkles';
import AddTaskModal from './components/AddTaskModal';
import StatsView from './components/StatsView';
import SettingsView from './components/SettingsView';
import { Task, SparkleType, Tab } from './types';

// Mock data generator
const generateTasks = (): Task[] => [
  { id: '1', text: "Wake up at 5 AM", color: 'yellow', rotation: -1.5, energy: 120, date: 'Oct 24', sticker: '☕' },
  { id: '2', text: "Dieting for summer", color: 'grey', rotation: 2, energy: 350, date: 'Oct 25', sticker: '🌿' },
  { id: '3', text: "Reply to all emails", color: 'latte', rotation: -0.8, energy: 80, date: 'Today' },
];

const App: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>(generateTasks());
  const [history, setHistory] = useState<Task[]>([]);
  const [sparkles, setSparkles] = useState<SparkleType[]>([]);
  const [energySaved, setEnergySaved] = useState(450);
  const [tasksGivenUpCount, setTasksGivenUpCount] = useState(12); // Mock initial count
  const [activeTab, setActiveTab] = useState<Tab>('home');
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  // Track unique IDs for sparkles
  const sparkleIdCounter = useRef(0);

  const handleGiveUp = useCallback((id: string, x: number, y: number) => {
    // 1. Find task to get energy
    const task = tasks.find(t => t.id === id);
    if (!task) return;

    // 2. Trigger Sparkles
    const newSparkles: SparkleType[] = Array.from({ length: 12 }).map(() => ({
      id: `sparkle-${sparkleIdCounter.current++}`,
      x,
      y,
      color: ['#D97706', '#F59E0B', '#FCD34D', '#A8A29E'][Math.floor(Math.random() * 4)]
    }));

    setSparkles(prev => [...prev, ...newSparkles]);
    
    // Clean up sparkles after animation
    setTimeout(() => {
      setSparkles(prev => prev.filter(s => !newSparkles.find(ns => ns.id === s.id)));
    }, 1000);

    // 3. Update Energy and History
    setEnergySaved(prev => prev + task.energy);
    setTasksGivenUpCount(prev => prev + 1);
    
    // Add to history with current date if it was 'Today' or 'Just now'
    const historyTask = { ...task, date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) };
    setHistory(prev => [historyTask, ...prev]);

    // 4. Remove Task
    setTasks(prev => prev.filter(t => t.id !== id));
  }, [tasks]);

  const handleAddTask = (text: string, color: Task['color'], sticker: string) => {
    const newTask: Task = {
      id: Date.now().toString(),
      text,
      color,
      rotation: (Math.random() * 4) - 2,
      energy: Math.floor(Math.random() * 200) + 50, // Random energy calculation
      date: 'Just now',
      sticker: sticker || undefined
    };
    setTasks(prev => [newTask, ...prev]);
    // Switch to home to see the new task
    setActiveTab('home');
  };

  const handleReset = () => {
    setEnergySaved(0);
    setTasksGivenUpCount(0);
    setHistory([]);
    setTasks(generateTasks());
    setActiveTab('home');
  };

  return (
    // h-[100dvh] ensures it fits mobile browser viewports exactly without scrollbars
    <div className="h-[100dvh] w-full relative overflow-hidden bg-background flex flex-col">
      <NoiseOverlay />
      
      {/* Header Section - Uses safe-area-inset-top for notch support */}
      <header className="relative z-10 pt-[calc(2rem+env(safe-area-inset-top))] pb-6 px-6 flex justify-between items-end shrink-0">
        <div>
          <motion.div 
            key={activeTab}
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            <h1 className="font-serif text-4xl md:text-5xl font-bold text-ink mb-1 tracking-tight">
              {activeTab === 'home' && "Let it go."}
              {activeTab === 'stats' && "Your Impact."}
              {activeTab === 'settings' && "Settings."}
            </h1>
            
            {activeTab === 'home' && (
              <div className="flex items-center gap-2 text-ink-light">
                <Wind size={16} className="text-accent-orange" />
                <p className="font-sans text-sm font-medium tracking-wide">
                  Energy saved: <span className="text-accent-orange font-bold font-serif italic text-lg">{energySaved}</span> kcal
                </p>
              </div>
            )}
             {activeTab === 'stats' && (
              <p className="font-sans text-sm font-medium tracking-wide text-ink-light">
                Quantifying your peace of mind.
              </p>
            )}
          </motion.div>
        </div>
        
        <motion.div 
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="w-12 h-12 rounded-full bg-paper-white shadow-soft flex items-center justify-center border border-white/50"
        >
          <img 
            src="https://picsum.photos/100/100" 
            alt="User" 
            className="w-10 h-10 rounded-full object-cover opacity-90 hover:opacity-100 transition-opacity"
          />
        </motion.div>
      </header>

      {/* Main Content Area - pb accounts for bottom nav + safe area */}
      <main className="relative z-10 flex-1 overflow-y-auto pb-[calc(6rem+env(safe-area-inset-bottom))] no-scrollbar">
        <AnimatePresence mode='wait'>
          {activeTab === 'home' && (
            <motion.div
              key="home"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="px-4"
            >
              <div className="columns-2 gap-4 space-y-4">
                <AnimatePresence mode='popLayout'>
                  {tasks.map((task, index) => (
                    <StickyNote 
                      key={task.id} 
                      task={task} 
                      onGiveUp={handleGiveUp}
                      index={index}
                    />
                  ))}
                </AnimatePresence>
              </div>
              
              {tasks.length === 0 && (
                <motion.div 
                  initial={{ opacity: 0 }} 
                  animate={{ opacity: 1 }}
                  className="text-center py-20 text-ink-light/40"
                >
                  <Coffee size={48} className="mx-auto mb-4 opacity-50" />
                  <p className="font-serif text-xl italic">You are perfectly at peace.</p>
                </motion.div>
              )}
            </motion.div>
          )}

          {activeTab === 'stats' && (
             <StatsView 
               key="stats" 
               energySaved={energySaved} 
               tasksGivenUp={tasksGivenUpCount} 
               history={history}
             />
          )}

          {activeTab === 'settings' && (
             <SettingsView key="settings" onReset={handleReset} />
          )}
        </AnimatePresence>
      </main>

      {/* UI Elements */}
      <Sparkles sparkles={sparkles} />
      
      <GlassNavigation 
        activeTab={activeTab} 
        onTabChange={setActiveTab} 
        onAddClick={() => setIsModalOpen(true)} 
      />

      <AddTaskModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        onAdd={handleAddTask} 
      />
      
    </div>
  );
};

export default App;